#pragma region LICENSE

// Read the Gnu General Public License v3.0 at: https://www.gnu.org/licenses/gpl-3.0.html

#pragma endregion LICENSE

#pragma once

#ifndef PixelForge_WINDOW_HPP
#define PixelForge_WINDOW_HPP

#include "config/openGL.h"

#if defined(PixelForge_OS_Windows)

LRESULT CALLBACK wnd_proc(HWND hwnd, UINT msg, WPARAM w_param, LPARAM l_param);

namespace pf
{
    class Window
    {
    public:
        Window(int width, int height, const wchar_t* name);
        ~Window();

        Window(const Window &) = delete;
        Window &operator = (const Window &) = delete;

        bool process_message();
    
    private:
        const wchar_t* m_name;
        HINSTANCE m_hinstance;
        HWND m_hwnd;
    };
} // namespace pf

#elif defined(PixelForge_OS_MacOS)

namespace pf
{
    class Window
    {
    public:
        Window(int width, int height, const wchar_t* name);
        ~Window();

        Window(const Window &) = delete;
        Window &operator = (const Window &) = delete;

        bool process_message();
    
    private:
        const wchar_t* m_name;
        NSWindow* m_wnd;
        NSApplication* m_app;
    };
} // namespace pf

#elif defined(PixelForge_OS_Linux)

namespace pf
{
    class Window
    {
    public:
        Window(int width, int height, const wchar_t* name);
        ~Window();

        Window(const Window &) = delete;
        Window &operator = (const Window &) = delete;

        bool process_message();
    
    private:
        const wchar_t* m_name;
        Display m_display;
        Window* m_wnd;
        Atom m_delete_msg;

    };
} // namespace pf

#endif // PixelForge_OS_Windows

#endif // PixelForge_WINDOW_HPP