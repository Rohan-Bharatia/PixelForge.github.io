# Win32 Window Class
## Overview
The ```Window``` class is designed to open a window on any Windows, MacOS, or Linux operating system.

## ```Window```
Create a blank window
```cpp
Window(int width, int height, const wchar_t* name)
```

### Parameters
 * ```width```: The width (x-axis) of the window
 * ```height```: The height (y-axis) of the window
 * ```name```: The name the window

### Implementation
```cpp
pf::Window* window = new pf::Window(L"PixelForge Test Application");
```

--------------------------------------------------------------------

## ```process_message```
Check if the window has been closed
```cpp
bool process_message();
```

### Implementation
```cpp
pf::Window* window = new pf::Window(L"PixelForge Test Application");

if(window->process_message())
{
    // Do something
}
```

--------------------------------------------------------------------

## Full Implementation
```cpp
int main(int argc, char* argv[])
{
    std::cout << "Creating Window..." << std::endl;
    
    pf::Window* window = new pf::Window(L"PixelForge Test Application");

    bool running = true;
    while(running)
    {
        if(window->process_message())
        {
            std::cout << "Closing Window..." << std::endl;

            running = false;
        }

        // Render

        Sleep(10);
    }

    delete window;
    return 0;
}
```